import requests
target = 'https://csec.rit.edu'
resp = requests.get(target)
print(resp)